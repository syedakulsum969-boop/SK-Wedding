# Kulsum & Qayyum — Wedding Invitation Website

A responsive, single-page wedding invitation with:
- Animated 3D-style envelope and wax seal reveal
- Background music playback after the guest taps the envelope
- Nikah details and optional countdown
- RSVP form (connects to Formspree)
- Optional Google Maps link

## 1. Personalize the event

Open `script.js` and edit the `CONFIG` object near the top:

```js
const CONFIG = {
  eventDateTime: "", // Add the confirmed time and UTC offset to activate countdown
  dateText: "Thursday, January 7, 2027",
  timeText: "Time to be announced",
  venueText: "Oasis Palace, Newark, California",
  mapUrl: "https://maps.google.com/?q=...",
  formspreeEndpoint: "https://formspree.io/f/xxxxxxxx"
};
```

Use your actual event date/time and the correct local UTC offset. The example date is only a placeholder.

## 2. Connect RSVP submissions

1. Create a free form at https://formspree.io/.
2. Create a form and verify the email address where responses should arrive.
3. Copy the form endpoint (it looks like `https://formspree.io/f/xxxxxxxx`).
4. Paste it into `formspreeEndpoint` in `script.js`.
5. Publish the updated files and submit a test RSVP.

Until you add the endpoint, the form runs in preview mode and does not store or send guest responses. For guest privacy, only collect details you need and restrict access to the RSVP inbox.

## 3. Add background music

Add a legally usable MP3 file named exactly:

`assets/romantic-instrumental.mp3`

Use music you own or have permission/license to use. No copyrighted Bollywood recording is included. The browser starts playback only after the guest taps the envelope, because browsers generally block autoplay with sound.

## 4. Preview on your computer

Double-click `index.html` to open it in a browser. Most features work locally; test the RSVP only after connecting Formspree and publishing.

## 5. Publish with GitHub Pages

1. Sign in at https://github.com/.
2. Click **New repository**.
3. Name it `kulsum-qayyum-wedding` and choose **Public** (GitHub Pages availability depends on your plan/repository settings).
4. Upload `index.html`, `styles.css`, `script.js`, `README.md`, and the `assets` folder.
5. Open the repository's **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Choose branch `main` and folder `/ (root)`, then click **Save**.
8. Wait for deployment. Your site address will look like:
   `https://YOUR-GITHUB-USERNAME.github.io/kulsum-qayyum-wedding/`

Whenever you edit the files and push/upload the changes to `main`, GitHub Pages republishes the site.

## Notes
- Date, time, venue and map link are placeholders until you fill them in.
- The RSVP form does not send anywhere until Formspree is configured.
- Do not publish private phone numbers, home addresses or guest lists in the repository.
