/*
  BEFORE PUBLISHING:
  1) Edit the event details in the CONFIG object below.
  2) Create a free Formspree form and paste its endpoint into FORMSPREE_ENDPOINT.
  3) Add a licensed/royalty-free MP3 named assets/romantic-instrumental.mp3.
*/
const CONFIG = {
  eventDateTime: "", // Add the confirmed local event time to enable the live countdown.
  dateText: "Thursday, January 7, 2027",
  timeText: "Time to be announced",
  venueText: "Oasis Palace, Newark, California",
  mapUrl: "", // Optional Google Maps URL
  formspreeEndpoint: "" // Example: "https://formspree.io/f/xxxxxxxx"
};

const opening = document.getElementById("opening");
const invitation = document.getElementById("invitation");
const audio = document.getElementById("weddingMusic");
const musicToggle = document.getElementById("musicToggle");
const openButton = document.getElementById("openInvitation");

document.getElementById("eventDate").textContent = CONFIG.dateText;
document.getElementById("eventTime").textContent = CONFIG.timeText;
document.getElementById("eventVenue").textContent = CONFIG.venueText;
if (CONFIG.mapUrl) {
  const mapLink = document.getElementById("mapLink");
  mapLink.href = CONFIG.mapUrl;
  mapLink.hidden = false;
}

function updateMusicButton() {
  const playing = !audio.paused;
  musicToggle.setAttribute("aria-pressed", String(playing));
  musicToggle.querySelector("span").textContent = playing ? "Pause music" : "Play music";
}
async function startMusic() {
  try { await audio.play(); } catch (error) {
    document.getElementById("formMessage").textContent =
      "Add your music file to the assets folder to enable background music.";
  }
  updateMusicButton();
}
openButton.addEventListener("click", async () => {
  if (opening.classList.contains("opened")) return;
  opening.classList.add("opened");
  startMusic();
  window.setTimeout(() => {
    opening.classList.add("fade-away");
    window.setTimeout(() => {
      opening.classList.add("hidden");
      invitation.classList.remove("hidden");
      invitation.scrollIntoView({ behavior: "smooth" });
    }, 650);
  }, 1050);
});
musicToggle.addEventListener("click", async () => {
  if (audio.paused) await startMusic();
  else audio.pause();
  updateMusicButton();
});
audio.addEventListener("play", updateMusicButton);
audio.addEventListener("pause", updateMusicButton);

function updateCountdown() {
  if (!CONFIG.eventDateTime) return;
  const distance = new Date(CONFIG.eventDateTime).getTime() - Date.now();
  if (Number.isNaN(distance)) return;
  const values = distance <= 0 ? [0, 0, 0, 0] : [
    Math.floor(distance / 86400000),
    Math.floor((distance % 86400000) / 3600000),
    Math.floor((distance % 3600000) / 60000),
    Math.floor((distance % 60000) / 1000)
  ];
  ["days", "hours", "minutes", "seconds"].forEach((id, i) => {
    document.getElementById(id).textContent = String(values[i]).padStart(2, "0");
  });
}
updateCountdown();
window.setInterval(updateCountdown, 1000);

const form = document.getElementById("rsvpForm");
const message = document.getElementById("formMessage");
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!CONFIG.formspreeEndpoint) {
    message.textContent = "RSVP preview only: connect your Formspree endpoint in script.js to receive guest responses.";
    return;
  }
  const submitButton = form.querySelector('button[type="submit"]');
  submitButton.disabled = true;
  submitButton.textContent = "Sending…";
  message.textContent = "";
  try {
    const response = await fetch(CONFIG.formspreeEndpoint, {
      method: "POST",
      body: new FormData(form),
      headers: { Accept: "application/json" }
    });
    if (!response.ok) throw new Error("Submission failed");
    form.reset();
    message.textContent = "Thank you! Your RSVP has been received. We look forward to celebrating with you.";
  } catch (error) {
    message.textContent = "Sorry, your RSVP could not be sent. Please try again or contact the hosts.";
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "Send RSVP";
  }
});
